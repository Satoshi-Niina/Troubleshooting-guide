import path from 'path';
import { processPptx } from './processPptx';
import { processPdf } from './processPdf';
import { processDocx } from './processDocx';
import { processXlsx } from './processXlsx';
import { processTxt } from './processTxt';

export function processFile(inputPath: string, outputDir: string) {
  const ext = path.extname(inputPath).toLowerCase();
  switch (ext) {
    case '.pptx': return processPptx(inputPath, outputDir);
    case '.pdf': return processPdf(inputPath, outputDir);
    case '.docx': return processDocx(inputPath, outputDir);
    case '.xlsx': return processXlsx(inputPath, outputDir);
    case '.txt': return processTxt(inputPath, outputDir);
    default: console.error('Unsupported file format:', ext);
  }
}
