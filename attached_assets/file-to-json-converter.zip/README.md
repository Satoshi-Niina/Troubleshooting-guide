# ファイル一括変換スクリプト

## 対応ファイル形式:
- PPTX
- PDF
- DOCX
- XLSX
- TXT

## 出力:
- knowledge_chunks.json (GPT用)
- search_data.json (Fuse.js用)
- images/ (抽出画像)

## 実行方法:
```
npm install
npx ts-node convert-file-to-json.ts
```
`input/` フォルダにファイルを置くと、自動で `output/` に変換結果が出力されます。
