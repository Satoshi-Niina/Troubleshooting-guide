import { processFile } from './utils/processor';
import fs from 'fs';
import path from 'path';

// 入力フォルダと出力先
const inputDir = './input';
const outputDir = './output';

fs.readdirSync(inputDir).forEach(file => {
  const inputPath = path.join(inputDir, file);
  processFile(inputPath, outputDir);
});
